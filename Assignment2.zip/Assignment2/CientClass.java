package com.assignment1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CientClass {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Movie movie=(Movie)context.getBean("movie");
		System.out.println("Movie Id : "+movie.getMovieId());
		System.out.println("Movie Name : "+movie.getMovieName());
		System.out.println("Movie Actor Name : "+movie.getMovieActor());
		

	}

}

package com.assignment3;

public class Test {
	private String testId;
	private String testName;
	private int testmarks;
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public int getTestmarks() {
		return testmarks;
	}
	public void setTestmarks(int testmarks) {
		this.testmarks = testmarks;
	}
	@Override
	public String toString() {
		return "Test [testId=" + testId + ", testName=" + testName + ", testmarks=" + testmarks + "]";
	}
	
	

}

package com.assignment3;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CientClass {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("Studentbeans.xml");
		Student student1=(Student)context.getBean("student");
		Student student2=(Student)context.getBean("student1");
		System.out.println("Student and Test result details  : "+student1.toString());
		System.out.println("Student and Test result details  : "+student2.toString());
		

		

	}

}

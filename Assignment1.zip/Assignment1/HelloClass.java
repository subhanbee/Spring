package com.assignment1;

public class HelloClass {
	private String string;

	public HelloClass(String string) {
		super();
		this.string = string;
	}

	@Override
	public String toString() {
		return string;
	}
	

}

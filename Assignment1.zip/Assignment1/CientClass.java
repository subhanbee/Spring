package com.assignment1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CientClass {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("beansWorld.xml");
		HelloClass hello=(HelloClass)context.getBean("hello");
		System.out.println(hello);
		
		

	}

}

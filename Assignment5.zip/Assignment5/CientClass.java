package com.assignment4;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CientClass {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("CountryBeans.xml");
		ArrayList<Player> listOfPlayers=new ArrayList<Player>();
		Player player1=(Player)context.getBean("player1");
		Player player2=(Player)context.getBean("player2");
		Player player3=(Player)context.getBean("player3");
		Player player4=(Player)context.getBean("player4");
		Player player5=(Player)context.getBean("player5");
		listOfPlayers.add(player1);
		listOfPlayers.add(player2);
		listOfPlayers.add(player3);
		listOfPlayers.add(player4);
		listOfPlayers.add(player5);
		System.out.println("Player Name and country details  : "+player1.toString());
		System.out.println("Player Name and country details  : "+player2.toString());
		System.out.println("Player Name and country details  : "+player3.toString());
		System.out.println("Player Name and country details  : "+player4.toString());
		System.out.println("Player Name and country details  : "+player5.toString());
		System.out.println("Getting the INDIA Country Players details: " );
		 Country co=player1.getCountry();
		
		for(Player player:listOfPlayers) {
			if(co.equals(player.getCountry())) {
				System.out.println(player);
			}
			
		}
			System.out.println("Getting the SriLanka Country Players details: " );
			 Country co1=player4.getCountry();
				
				for(Player player:listOfPlayers) {
					if(co1.equals(player.getCountry())) {
						System.out.println(player);
					}
		}
		

		

	}

}
